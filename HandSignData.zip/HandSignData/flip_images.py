

from PIL import Image
import os
curr_dir = os.getcwd()
dir_elements = os.listdir(curr_dir)


for x in os.listdir(os.getcwd()):
    
    original_img = Image.open(f"{x}")
        
            
        # Flip the original image horizontally
    horz_img = original_img.transpose(method=Image.FLIP_LEFT_RIGHT)
    horz_img.save(f"rev_{x}")
        
        # close all our files object
    original_img.close()
    os.remove(f"{x}")
    horz_img.close()